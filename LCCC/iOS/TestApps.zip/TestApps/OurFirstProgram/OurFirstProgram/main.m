//
//  main.m
//  OurFirstProgram
//
//  Created by UC224 on 1/19/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

//
//  AppDelegate.h
//  OurFirstProgram
//
//  Created by UC224 on 1/19/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


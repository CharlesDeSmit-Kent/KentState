//
//  ViewController.m
//  MovingShip
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController



-(void) viewTapped:(UIGestureRecognizer *)aGesture
{
    UITapGestureRecognizer *ourTap=(UITapGestureRecognizer *) aGesture;
    CGPoint tapPoint=[ourTap locationInView:self.view];
    [self.ship setMoveToPoint:tapPoint];
    [self.ship calculateSpeed];
}
-(void) updateStuff
{
    [self.ship updateLocation];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //create the ship here
    //need to create timer here
    //need to add gesture recognizer here
    self.ship=[ClassShip new];
    CGRect ourFrame=[self.view frame];
    
    self.ship.center=CGPointMake(ourFrame.size.width/2, ourFrame.size.height/2);
    [self.view addSubview:_ship];
    [self.ship setMoveToPoint:_ship.center];
    
    // self.ourTimer=[NSTimer scheduledTimerWithTimeInterval:1/30.0f target:self selector:@selector(updateStuff) userInfo:nil repeats:YES];
    
    self.ourDisplayLink=[CADisplayLink displayLinkWithTarget:self selector:@selector(updateStuff)];
    
    [_ourDisplayLink setPreferredFramesPerSecond:30];
    [_ourDisplayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    
    UIGestureRecognizer *tapScreen=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    [self.view addGestureRecognizer:tapScreen];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

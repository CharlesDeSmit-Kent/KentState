//
//  ViewController.h
//  MovingShip
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClassShip.h"

@interface ViewController : UIViewController

@property (strong, nonatomic) CADisplayLink *ourDisplayLink;


@property (strong, nonatomic) NSTimer *ourTimer;
@property (strong, nonatomic) ClassShip *ship;

-(void) updateStuff;
-(void) viewTapped:(UIGestureRecognizer *) aGesture;


@end


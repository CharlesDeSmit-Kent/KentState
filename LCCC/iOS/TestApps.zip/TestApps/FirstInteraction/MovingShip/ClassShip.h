//
//  ClassShip.h
//  MovingShip
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassShip : UIImageView

@property (assign, nonatomic) float speed;
@property (assign, nonatomic) CGPoint moveToPoint;

@property (assign, nonatomic) float Vx;
@property (assign, nonatomic) float Vy;

-(void) calculateSpeed;
-(void) updateLocation;

@end

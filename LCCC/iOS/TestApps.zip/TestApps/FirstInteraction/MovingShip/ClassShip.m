//
//  ClassShip.m
//  MovingShip
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "ClassShip.h"

@implementation ClassShip

-(id)init
{
    self=[super initWithImage:[UIImage imageNamed:@"ship"]];
    if (self!=nil)
    {
        [self setSpeed:3.0f];
    }
    return self;
}


-(void) calculateSpeed
{
    CGPoint c=[self center]; //save current point in c
    float diffx= _moveToPoint.x-c.x;
    float diffy= _moveToPoint.y-c.y;
    
    if (diffx!=0)
    {
        float alpha=atan(diffy/diffx);
        _Vx= _speed*cos(alpha);
        _Vy= _speed*sin(alpha);
        if (diffx<0)
        {
            _Vx= _Vx*(-1);
            _Vy= _Vy*(-1);
        }
    }else
    {
        _Vx=0;
        if(diffy<0) _Vy=self.speed;
        else if (diffy!=0) _Vy=self.speed;
        else _Vy=0;
        
    }

}

-(void) updateLocation
{
    CGPoint c=[self center];
    float diffx= _moveToPoint.x-c.x;
    float diffy= _moveToPoint.y-c.y;
    
    float distance=sqrtf(diffx*diffx*diffy*diffy);
    
    if (distance>_speed)
    {
        c.x=c.x+_Vx*1;//1 is the unit of time
        c.y=c.y+_Vy*1;
    }else
    {
        c.x=_moveToPoint.x;
        c.y=_moveToPoint.y;
    }
    
    [self setCenter:c];

}

@end

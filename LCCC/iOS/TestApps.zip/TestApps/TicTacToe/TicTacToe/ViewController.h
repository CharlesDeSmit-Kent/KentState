//
//  ViewController.h
//  TicTacToe
//
//  Created by UC224 on 2/23/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


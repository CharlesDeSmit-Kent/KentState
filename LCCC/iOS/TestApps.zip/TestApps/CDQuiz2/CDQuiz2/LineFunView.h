//
//  LineFunView.h
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"

@interface QuartzFunView : UIView

@property (assign, nonatomic) CDShapeType CDshapeType;


@property (strong, nonatomic) UIColor *CDcurrentColor;

@end

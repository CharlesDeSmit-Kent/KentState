//
//  Shape.m
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "Shape.h"

@implementation Shape

-(void) drawShape:(CGContextRef) context{
    // CGContextRef context=UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2.0);
    CGContextSetStrokeColorWithColor(context,self.shapeColor.CGColor);
    CGContextSetFillColorWithColor(context, self.shapeColor.CGColor);
    
    CGRect currentRect=self.rect;
    
    switch (self.CDshapeType) {
        case CDLineShape:
            //CGContextMoveToPoint(context, currentRect.origin.x, currentRect.origin.y);
            //CGContextAddLineToPoint(context,currentRect.origin.x+currentRect.size.width, currentRect.origin.y+currentRect.size.height);
            CGContextMoveToPoint(context, currentRect.origin.x, currentRect.origin.y);
            switch (self.CDdirect) {
                case CDHori:
                    CGContextAddLineToPoint(context,currentRect.origin.x+50, currentRect.origin.y);
                    break;
                case CDVert:
                    CGContextAddLineToPoint(context,currentRect.origin.x, currentRect.origin.y+50);
                    break;
                    
                default:
                    break;
            }
            CGContextStrokePath(context);
            break;
            
        default:
            break;
    }
}


@end

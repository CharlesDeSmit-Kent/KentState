//
//  Shape.h
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"
#import <UIKit/UIKit.h>
@interface Shape : NSObject

@property (assign, nonatomic) CDShapeType CDshapeType;
@property (assign, nonatomic) CDDirect CDdirect;
@property (assign, nonatomic) CGRect rect;
@property (strong, nonatomic) UIColor *shapeColor;

-(void) drawShape:(CGContextRef) context;


@end

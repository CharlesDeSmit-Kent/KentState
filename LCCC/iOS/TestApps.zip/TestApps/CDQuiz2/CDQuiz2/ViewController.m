//
//  ViewController.m
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "ViewController.h"
#import "Constants.h"
#import "LineFunView.h"


@interface ViewController ()
@property (strong, nonatomic) IBOutlet UISegmentedControl *CDDirectionSelect;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)SelectDirect:(UISegmentedControl *)sender {
    //CDLineFunView *funView=(QuartzFunView *) self.view;
    CDDirect index=[sender selectedSegmentIndex];
}




@end

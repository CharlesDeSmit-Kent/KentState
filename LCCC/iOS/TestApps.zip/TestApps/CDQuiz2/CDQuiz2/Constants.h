//
//  Constants.h
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

typedef NS_ENUM(NSInteger, CDShapeType)
{
    CDLineShape=0
    
};

typedef NS_ENUM(NSInteger, CDDirect)
{
    CDHori=0,
    CDVert,
};

#endif

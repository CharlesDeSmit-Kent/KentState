//
//  LineFunView.m
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "LineFunView.h"
#import "Shape.h"

@interface QuartzFunView()

@property (assign,nonatomic) CGPoint firstTouchLocation;
@property (assign,nonatomic) CGPoint lastTouchLocation;
@property (strong, nonatomic) NSMutableArray *ourShapes;

@end


@implementation QuartzFunView

-(id) initWithCoder:(NSCoder *)aDecoder
{
    if (self=[super initWithCoder:aDecoder])
    {
        _CDcurrentColor=[UIColor redColor];
        _ourShapes=[[NSMutableArray alloc] init];
    }
    
    return self;
}

#pragma mark-Touch Handling

-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch=[touches anyObject];
    self.firstTouchLocation=[touch locationInView:self];
    self.lastTouchLocation=[touch locationInView:self];
    [self setNeedsDisplay];
}

-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch=[touches anyObject];
    self.lastTouchLocation=[touch locationInView:self];
    CGRect currentRect=CGRectMake(self.firstTouchLocation.x, self.firstTouchLocation.y, self.lastTouchLocation.x-self.firstTouchLocation.x, self.lastTouchLocation.y-self.firstTouchLocation.y);
    
    Shape *shape=[[Shape alloc]init];
    [shape  setRect:currentRect];
    //[shape setShapeType:self.CDshapeType];
    [shape setShapeColor:self.CDcurrentColor];
    [self.ourShapes addObject:shape];
    [self setNeedsDisplay];
    
    
}
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch=[touches anyObject];
    self.lastTouchLocation=[touch locationInView:self];
    [self setNeedsDisplay];
    
    
}




- (void)drawRect:(CGRect)rect {
    CGContextRef context=UIGraphicsGetCurrentContext();
    
    [self drawAllOurStuff:context];
    
    
    CGContextSetLineWidth(context, 2.0);
    CGContextSetStrokeColorWithColor(context, self.CDcurrentColor.CGColor);
    
    CGContextSetFillColorWithColor(context, self.CDcurrentColor.CGColor);
    //CGRect currentRect=CGRectMake(self.firstTouchLocation.x, self.firstTouchLocation.y, self.lastTouchLocation.x-self.firstTouchLocation.x, self.lastTouchLocation.y-self.firstTouchLocation.y);
    
    // CGContextMoveToPoint(context, self.lastTouchLocation.x,self.lastTouchLocation.y);
    // CGContextAddLineToPoint(context, self.lastTouchLocation.x+50,self.lastTouchLocation.y);
    // CGContextStrokePath(context);
    
    
}

-(void) drawAllOurStuff:(CGContextRef) context
{
    unsigned long n=_ourShapes.count;
    
    for (int i=0; i<n; i++)
    {
        Shape *user = (Shape *)[_ourShapes objectAtIndex:i];
        
        [user drawShape:context];
        
        
    }
    
}


@end

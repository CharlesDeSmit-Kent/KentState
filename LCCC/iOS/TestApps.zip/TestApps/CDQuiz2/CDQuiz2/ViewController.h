//
//  ViewController.h
//  CDQuiz2
//
//  Created by UC224 on 3/30/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


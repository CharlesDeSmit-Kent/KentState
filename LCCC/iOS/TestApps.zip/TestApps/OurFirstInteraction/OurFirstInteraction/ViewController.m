//
//  ViewController.m
//  OurFirstInteraction
//
//  Created by UC224 on 1/26/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *ourLabel;

@end

@implementation ViewController
- (IBAction)leftButt:(UIButton *)sender {
    NSString *nameButton=[sender titleForState:UIControlStateNormal];
    NSString *ourText=[NSString stringWithFormat:@"%@ Button Pressed", nameButton];
    
    _ourLabel.text=ourText;
}
/*
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
*/

@end

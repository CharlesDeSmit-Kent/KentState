//
//  ViewController.m
//  OurQuartzFun
//
//  Created by UC224 on 2/23/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "ViewController.h"
#import "OurQuartzFunView.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UISegmentedControl *colorControl;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeColor:(UISegmentedControl *)sender {
    OurQuartzFunView *funview=self.view;
    ColorTabIndex index=[sender selectedSegmentIndex];
    
    switch (index) {
        case kRedColorTab:
            funview.currentColor=[UIColor redColor];
            funview.userRandomColor=NO;
            break;
        case kBlueColorTab:
            funview.currentColor=[UIColor blueColor];
            funview.userRandomColor=NO;
            break;
        case kYellowColorTab:
            funview.currentColor=[UIColor yellowColor];
            funview.userRandomColor=NO;
            break;
        case kGreenColorTab:
            funview.currentColor=[UIColor greenColor];
            funview.userRandomColor=NO;
            break;
        case kRandomColorTab:
            funview.userRandomColor=YES;
            break;

        default:
            break;
    }
}
- (IBAction)changeShape:(UISegmentedControl *)sender {
    
    //OurQuartzFunView *ourView=self.view;
    //ourView.shapeType=[sender selectedSegmentIndex];
    [(OurQuartzFunView *)self.view setShapeType:[sender selectedSegmentIndex]];
    
   /* if ([sender selectedSegmentIndex]==kImageShape)
    {
        self.colorControl.hidden=YES;
    }*/
    self.colorControl.hidden=[sender selectedSegmentIndex]==kImageShape;
    
}

@end

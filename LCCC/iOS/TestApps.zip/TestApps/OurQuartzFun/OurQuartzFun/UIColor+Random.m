//
//  UIColor+Random.m
//  OurQuartzFun
//
//  Created by UC224 on 2/23/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "UIColor+Random.h"

@implementation UIColor (Random)

+(UIColor *) randomColor{
    
    CGFloat red=(CGFloat)(arc4random()%256)/255;
    CGFloat green=(CGFloat)(arc4random()%256)/255;
    CGFloat blue=(CGFloat)(arc4random()%256)/255;
    
    UIColor *ourColor;
    ourColor=[UIColor colorWithRed:red green:green blue:blue alpha:1.0f];
    
    return ourColor;                            
}

@end

//
//  OurQuartzFunView.m
//  OurQuartzFun
//
//  Created by UC224 on 2/23/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import "OurQuartzFunView.h"
#import "UIColor+Random.h"

@interface OurQuartzFunView()

@property (strong,nonatomic) UIImage *image;
//CGPoint = class with (x,y) coordinates
@property (assign,nonatomic) CGPoint firstTouchLocation;
@property (assign,nonatomic) CGPoint lastTouchLocation;

@end


@implementation OurQuartzFunView

-(id) initWithCoder:(NSCoder *)aDecoder
{
    if (self=[super initWithCoder:aDecoder])
    {
        _currentColor=[UIColor redColor];
        _userRandomColor=NO;
        _image=[UIImage imageNamed:@"iPhone"];
    }
    return self;
}

#pragma mark-Touch Handling

-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (self.userRandomColor)
    {
        self.currentColor=[UIColor randomColor];
    }
    UITouch *touch=[touches anyObject];
    self.firstTouchLocation=[touch locationInView:self];
    self.lastTouchLocation=[touch locationInView:self];
    [self setNeedsDisplay];
}

-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch=[touches anyObject];
    self.lastTouchLocation=[touch locationInView:self];
    [self setNeedsDisplay];
}

-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch=[touches anyObject];
    self.lastTouchLocation=[touch locationInView:self];
    [self setNeedsDisplay];
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    CGContextRef context=UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2.0);
    CGContextSetStrokeColorWithColor(context, self.currentColor.CGColor);
    CGContextSetFillColorWithColor(context, self.currentColor.CGColor);
    CGRect currentRect=CGRectMake(_firstTouchLocation.x, _firstTouchLocation.y, _lastTouchLocation.x-_firstTouchLocation.x, _lastTouchLocation.y-_firstTouchLocation.y);
    //CGRect CDcurrentRect=CGRectMake(_firstTouchLocation.x/2, _firstTouchLocation.y/2, (_lastTouchLocation.x-_firstTouchLocation.x)/2, (_lastTouchLocation.y-_firstTouchLocation.y)/2);

    switch (self.shapeType) {
        case kLineShape:
            CGContextAddEllipseInRect(context, currentRect);
            CGContextDrawPath(context, kCGPathFill);
            CGContextMoveToPoint(context, self.firstTouchLocation.x, self.firstTouchLocation.y);
            CGContextAddLineToPoint(context, self.lastTouchLocation.x, self.lastTouchLocation.y);
            CGContextStrokePath(context);
            break;
        case kRectShape:
            CGContextAddRect(context, currentRect);
            CGContextDrawPath(context, kCGPathFill);
            break;
        case kEllipseShape:
            CGContextAddEllipseInRect(context, currentRect);
            CGContextDrawPath(context, kCGPathFill);
            break;
        default:
            break;
    }
    /*CGContextMoveToPoint(context, self.firstTouchLocation.x, self.firstTouchLocation.y );
    CGContextAddLineToPoint(context, self.lastTouchLocation.x, self.lastTouchLocation.y );
    CGContextStrokePath(context);*/
}


@end

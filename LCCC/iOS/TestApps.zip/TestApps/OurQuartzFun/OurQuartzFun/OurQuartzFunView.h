//
//  OurQuartzFunView.h
//  OurQuartzFun
//
//  Created by UC224 on 2/23/17.
//  Copyright © 2017 Lorainccc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"
#import "UIColor+Random.h"

@interface OurQuartzFunView : UIView

@property (assign, nonatomic) Shapetype shapeType;
@property (assign, nonatomic) BOOL userRandomColor;
@property (assign, nonatomic) UIColor *currentColor;



@end
